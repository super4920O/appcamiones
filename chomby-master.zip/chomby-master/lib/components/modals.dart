import 'package:flutter/material.dart';

Future<void> showInfoDialog({
  required BuildContext context,
  required String title,
  required String content,
  String confirmText = "OK",
  VoidCallback? onConfirm,
}) {
  return showDialog<void>(
    context: context,
    barrierDismissible: false, // El diálogo no se cierra al hacer clic fuera
    builder: (BuildContext dialogContext) {
      return AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(dialogContext).pop(); // Cerrar el diálogo
              if (onConfirm != null) {
                onConfirm(); // Ejecutar la acción al confirmar
              }
            },
            child: Text(confirmText),
          ),
        ],
      );
    },
  );
}
