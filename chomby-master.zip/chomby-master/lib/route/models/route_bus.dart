class RouteBus {
  String name;
  double price;
  String? img;

  RouteBus({required this.name,required this.price, required this.img});

  factory RouteBus.fromJson(Map<String,dynamic> json){
    return RouteBus(
      name: json["name"],
      price: json["price"],
      img:json["img"]
    );
  }
}