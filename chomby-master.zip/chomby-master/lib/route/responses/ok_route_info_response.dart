import 'dart:convert';

import 'package:chomby/route/models/route_bus.dart';
import 'package:chomby/utils/http_response.dart';

class OkRouteInfoResponse extends HttpResponse<OkRouteInfoResponseBody>{

  OkRouteInfoResponse({required super.statusCode, required super.headers, required super.body});

  @override
  OkRouteInfoResponseBody mapJsonBody() {
    return OkRouteInfoResponseBody.fromJson(jsonDecode(body));
  }

}

class OkRouteInfoResponseBody {

  RouteBus route;

  OkRouteInfoResponseBody({required this.route});

  factory OkRouteInfoResponseBody.fromJson(Map<String,dynamic> json){
    return OkRouteInfoResponseBody(route: RouteBus.fromJson(json));
  }

}