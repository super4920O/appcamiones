import 'package:chomby/utils/http_response.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

abstract class RouteService {
  Future<List<LatLng>> getRoutePointsById(int routeId);
  Future<List<List<LatLng>>> getAllRoutesPoints();
  Future<HttpResponse> getRouteInfoById(int routeId);
}