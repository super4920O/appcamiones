import 'package:flutter/material.dart';

class RouteCard extends StatelessWidget {
  final String? name;
  final double? price;
  final String? imageUrl;
  final bool fromAssets;
  final double? rating;
  final int? stopsCount;
  final String? schedule;
  final String? description;

  const RouteCard({
    super.key,
    this.name,
    this.price,
    this.imageUrl,
    this.fromAssets = true,
    this.rating,
    this.stopsCount,
    this.schedule,
    this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      elevation: 4.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(15.0),
              topRight: Radius.circular(15.0),
            ),
            child: fromAssets
                ? Image.asset("assets/$imageUrl")
                : Image.network(
              imageUrl ?? "image",
              height: 150.0,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name ?? "Nombre ruta",
                  style: const TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8.0),
                Text(
                  price != null
                      ? 'Precio: \$${price!.toStringAsFixed(2)}'
                      : "\$0.0",
                  style: const TextStyle(
                    fontSize: 16.0,
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(height: 8.0),
                Row(
                  children: [
                    Icon(
                      Icons.star,
                      color: Colors.yellow[700],
                    ),
                    const SizedBox(width: 4.0),
                    Text(
                      rating != null ? rating.toString() : "Sin puntuación",
                      style: const TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8.0),
                Text(
                  "Número de paradas: ${stopsCount ?? 'N/A'}",
                  style: const TextStyle(
                    fontSize: 14.0,
                    color: Colors.black54,
                  ),
                ),
                const SizedBox(height: 8.0),
                Text(
                  "Horario: ${schedule ?? 'No disponible'}",
                  style: const TextStyle(
                    fontSize: 14.0,
                    color: Colors.black54,
                  ),
                ),
                const SizedBox(height: 8.0),
                Text(
                  description ?? "Descripción no disponible",
                  style: const TextStyle(
                    fontSize: 14.0,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
