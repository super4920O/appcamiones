import 'package:chomby/route/components/route_card.dart';
import 'package:chomby/route/models/route_bus.dart';
import 'package:flutter/material.dart';

class RouteShowScaffold extends StatelessWidget {

  final RouteBus bus;
  const RouteShowScaffold({super.key,required this.bus});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Detalle de la ruta"),
      ),
      body: Center(
        child: Align(
          alignment: Alignment.center,
          child: RouteCard(
            name: bus.name,
            price: bus.price,
            imageUrl: bus.img,
          ),
        ),
      ),
    );
  }
}
