
import 'package:chomby/layouts/auth_layout.dart';
import 'package:chomby/route/components/route_card.dart';
import 'package:chomby/route/responses/ok_route_info_response.dart';
import 'package:chomby/route/scaffolds/route_show_scaffold.dart';
import 'package:chomby/route/services/route_service.dart';
import 'package:chomby/utils/http_response.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:chomby/route/models/route_bus.dart';


class RoutesScaffold extends StatefulWidget {
  const RoutesScaffold({super.key});

  @override
  State<RoutesScaffold> createState() => _RoutesScaffoldsState();
}

class _RoutesScaffoldsState extends State<RoutesScaffold> {


  late RouteService _routeService;
  late Future<HttpResponse> _routeBus;
  @override
  void initState() {
    super.initState();
    _routeService = Provider.of<RouteService>(context,listen: false);

    _routeBus = _routeService.getRouteInfoById(1);
  }


  @override
  Widget build(BuildContext context) {
    return AuthLayout(
      title: const Text("Rutas"),
      child: FutureBuilder(
          future: _routeBus,
          builder: (context,snapshot){
            if(snapshot.connectionState == ConnectionState.waiting){
              return const Center(child: const CircularProgressIndicator());
            }else if(snapshot.hasError){
              return Center(child: Text("Error. ${snapshot.error}"));
            }else if(!snapshot.hasData){
              return const Center(child: const Text("No hay datos disponibles"));
            }else{

              RouteBus routeBus = (snapshot.data!.mapJsonBody() as OkRouteInfoResponseBody).route;
              return Card(
                margin: const EdgeInsets.all(8.0),
                child: ListTile(
                  leading: Image.asset("assets/${routeBus.img}"),
                  title: Text(routeBus.name),
                  subtitle: Text("Precio: \$${routeBus.price.toString()}"),
                  onTap: ()=>Navigator.of(context).push(MaterialPageRoute(builder: (context)=> RouteShowScaffold(bus: routeBus))),
                ),
              );
            }
          }
      )
    );
  }
}
