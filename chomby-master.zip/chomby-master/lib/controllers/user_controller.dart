import 'package:chomby/services/user_service.dart';
import 'package:get/get.dart';

import '../models/user.dart';

class UserController extends GetxController{

  late UserService _userService;

  var isLoading = true.obs;

  var userList = <User>[].obs;

  @override
  void onInit() {
    super.onInit();
    fetchUsers();
  }

  void fetchUsers() async {
    try{
      var users = await _userService.index();
      userList.assignAll(users);
    }finally{
      isLoading(false);
    }
  }

  void addUser(User user) async{
    try{
      isLoading(true);
      var newUser = await _userService.store(user);
      userList.add(newUser);
    }finally{
      isLoading(false);
    }
  }

  void updateUser(User user) async{
    try{
      isLoading(true);
      var updateUser = await _userService.update(user);
      int index = userList.indexWhere((u)=>u.id == user.id);

      if(index != -1){
        userList[index] = updateUser;
      }
    }finally{
      isLoading(false);
    }
  }

  void deleteUser(int id) async {
    try{
      isLoading(true);
      _userService.delete(id);
      userList.removeWhere((u)=>u.id == id);
    }finally{
      isLoading(false);
    }
  }
}