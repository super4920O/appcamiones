import 'package:chomby/authentication/scaffolds/login_scaffold.dart';
import 'package:chomby/route/scaffolds/routes_scaffold.dart';
import 'package:chomby/scaffolds/profile/navigation_scaffold.dart';
import 'package:flutter/material.dart';

class AuthLayout extends StatelessWidget {

  final Widget? child;
  final Widget? title;

  const AuthLayout({super.key,this.child,this.title});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(title: title ?? const Text("Título")),
      body: child,
      drawer:  Drawer(
        child: ListView(
          children:  <Widget>[
              const DrawerHeader(
              decoration:  BoxDecoration(
                color: Colors.blue
              ),
              child:  Text("Menú",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.map),
              title: const Text("Mapa"),
              onTap: ()=>Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=> const NavigationScaffold())),
            ),
            ListTile(
              leading: const Icon(Icons.route),
              title: const Text("Rutas"),
              onTap: ()=>Navigator.push(context,MaterialPageRoute(builder: (context)=>const RoutesScaffold())),
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text("Cerrar sesíon"),
              onTap: ()=>Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>const LoginScaffold())),
            )
          ],
        ),
      ),
    );
  }
}
