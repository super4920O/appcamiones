import 'dart:async';
import 'dart:developer';
import 'package:chomby/components/modals.dart';
import 'package:chomby/layouts/auth_layout.dart';
import 'package:chomby/route/services/route_service.dart';
import 'package:chomby/services/default_location_manager_service.dart';
import 'package:chomby/services/location_manager_service.dart';
import 'package:chomby/services/static_location_manager_service.dart';
import 'package:chomby/services/stomp_service.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:stomp_dart_client/stomp_dart_client.dart';


class NavigationScaffold extends StatefulWidget {
  const NavigationScaffold({super.key});

  @override
  State<NavigationScaffold> createState() => _NavigationScaffoldState();
}

class _NavigationScaffoldState extends State<NavigationScaffold> {

  late LocationManagerService _locationManagerService;
  late StompService _stompService;
  late RouteService _routeService;
  final Completer<GoogleMapController> _googleMapController = Completer<GoogleMapController>();

  static const CameraPosition _initialCameraPosition = CameraPosition(
    target: LatLng(19.048208, -98.147079),
    zoom: 14.4746,
  );

  Set<Circle> _circles = {};
  Set<Marker> _markers = {};
  Set<Polyline> _polylines = {};
/*  late Marker _chombyMarker;
  late LatLng _chombyCurrentPosition;*/
  late StompClient _stompClient;
  late BitmapDescriptor _chombyIcon;

  static const double _baseCircleRadius = 100; // Radio base en metros


  final List<Color> routeColors = [
    Colors.red,
    Colors.blue,
    Colors.green,
    Colors.orange,
    Colors.purple,
  ];


  @override
  void initState() {
    super.initState();
    _locationManagerService = Provider.of<LocationManagerService>(context,listen:false);
    _stompService = Provider.of<StompService>(context,listen: false);
    _routeService = Provider.of<RouteService>(context,listen: false);


    _stompService.connect();
    _stompService.subscribe("/topic/app", (message){
        List<String> cords = message.split(",");
        _updateChombyMarketPosition(double.parse(cords[0]), double.parse(cords[1]));
    });

    _centerMapOnUserLocation();

    BitmapDescriptor.fromAssetImage(
        const ImageConfiguration(size: Size(10, 10)), 'assets/chomby_icon.png')
        .then((onValue) {
      _chombyIcon = onValue;
    });

/*    _routeService.getRoutePointsById(1)
      .then((routePoints){
        setState(() {
          _polylines.add(
            Polyline(
              polylineId: const PolylineId("route_1"),
              points: routePoints,
              color: Colors.red,
              width: 5
            )
          );
        });
    });*/

    _routeService.getAllRoutesPoints().then((pointsRoutesList) {
      setState(() {
        for (var i = 0; i < pointsRoutesList.length; i++) {
          final points = pointsRoutesList[i];
          _polylines.add(Polyline(
            polylineId: PolylineId("route_$i"),
            points: points,
            color: routeColors[i % routeColors.length], // Puedes personalizar el color
            width: 5, // Personaliza el grosor de la línea
          ));
        }
      });
    });


  }

  @override
  void dispose() {
    super.dispose();
    _stompService.disconect();
    //_stompClient.deactivate();
  }

  @override
  Widget build(BuildContext context) {
    return AuthLayout(
      title: const Text("Mapa"),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        child: Column(
          children: <Widget>[
            Expanded(
              child: GoogleMap(
                mapType: MapType.normal,
                initialCameraPosition: _initialCameraPosition,
                polylines: _polylines,
                circles: _circles,
                markers: _markers,
                onMapCreated: (GoogleMapController controller) {
                  _googleMapController.complete(controller);
                },
                onCameraMove: _updateCircleSize,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _centerMapOnUserLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      showInfoDialog(
        context: context,
        title: "Servicio de ubicación deshabilitado",
        content: "Por favor, habilita el servicio de ubicación.",
      );
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        showInfoDialog(
          context: context,
          title: "Permisos de ubicación denegados",
          content: "No se puede acceder al mapa sin los permisos necesarios.",
        );
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      showInfoDialog(
        context: context,
        title: "Permisos de ubicación denegados permanentemente",
        content: "Habilita los permisos manualmente desde la configuración.",
      );
      return;
    }

    try {
      Position position = await _locationManagerService.getCurrentPosition();
      final GoogleMapController controller = await _googleMapController.future;
      controller.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(
            target: LatLng(position.latitude, position.longitude),
            zoom: _initialCameraPosition.zoom,
          ),
        ),
      );

      _updateCircle(position.latitude, position.longitude);
    } catch (e) {
      showInfoDialog(
        context: context,
        title: "Error de ubicación",
        content: "No se pudo obtener la ubicación. Inténtalo de nuevo.",
      );
    }
  }


  void _updateCircle(double latitude, double longitude) {
    setState(() {
      _circles = {
        Circle(
          circleId: const CircleId('user_location'),
          center: LatLng(latitude, longitude),
          radius: _baseCircleRadius, // Se utilizará para calcular el radio visual
          strokeColor: Colors.blueAccent,
          strokeWidth: 2,
          fillColor: Colors.blue.withOpacity(0.5),
        ),
      };
    });
  }

  void _updateCircleSize(CameraPosition position) {
    // Calcula el nuevo radio en función del zoom
    double zoom = position.zoom;
    double radius = _baseCircleRadius * (1 / (1 << (zoom.toInt() - 14))); // Ajusta el radio en función del zoom

    // Actualiza el círculo con el nuevo radio
    setState(() {
      if (_circles.isNotEmpty) {
        _circles = {
          Circle(
            circleId: const CircleId('user_location'),
            center: _circles.first.center,
            radius: radius, // Nuevo radio calculado
            strokeColor: Colors.blueAccent,
            strokeWidth: 2,
            fillColor: Colors.blue.withOpacity(0.5),
          ),
        };
      }
    });
  }


/*  void _onConnect(StompFrame frame){
    _stompClient.subscribe(
        destination: '/topic/app',
        callback: (StompFrame frame){

          List<String> cords = frame.body!.split(",");
          _updateChombyMarketPosition(double.parse(cords[0]), double.parse(cords[1]));
        }
    );
  }*/

  void _updateChombyMarketPosition(double lat, double lon){
    setState(() {
      _markers = {
        Marker(
          markerId: const MarkerId("chomby_location:marker"),
          position: LatLng(lat, lon),
          infoWindow: const InfoWindow(title: "Tu chomby"),
          icon: _chombyIcon
        )
      };
    });
  }
}
