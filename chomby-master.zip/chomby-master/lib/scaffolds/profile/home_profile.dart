import 'package:chomby/models/user.dart';
import 'package:chomby/authentication/scaffolds/register_scaffold.dart';
import 'package:chomby/services/user_service.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class HomeProfile extends StatefulWidget {
  const HomeProfile({super.key});

  @override
  State<HomeProfile> createState() => _HomeProfileState();
}

class _HomeProfileState extends State<HomeProfile> {

  late UserService _userService;
  late Future<List<User>> _future;
  List<User> _users = [];
  @override
  void initState() {
    super.initState();
    _userService = Provider.of<UserService>(context,listen: false);
    _future = _userService.index();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Lista de usuarios"),
      ),
      body: FutureBuilder<List<User>>(
          future: _future,
          builder: (context,snapshot){
            if(snapshot.connectionState == ConnectionState.waiting){
              return const Center(child: CircularProgressIndicator());
            }else if(snapshot.hasError){
              return Center(child: Text('Error: ${snapshot.error}'));
            }else if(!snapshot.hasData || snapshot.data!.isEmpty){
              return const  Center(child: Text("No hay usuarios"));
            }else{

              if(_users.isEmpty){
                _users = snapshot.data!;
              }

              return ListView.builder(
                itemCount: _users.length,
                itemBuilder: (context,index){
                  final user = _users[index];
                  return ListTile(
                    title: Text(user.fullName),
                    subtitle: Text(user.email),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (context)=>RegisterScaffold(user:user))),
                          icon: const Icon(Icons.edit),
                        ),
                        IconButton(
                          onPressed: () {
                            _userService.delete(user.id!);
                            setState(() {
                              _users.removeAt(index);
                            });
                          },
                          icon: const Icon(Icons.delete),
                        ),
                      ],
                    ),
                  );
                },
              );
            }
          }
      ),
      floatingActionButton: ElevatedButton(
          onPressed: ()=>Navigator.of(context).push(MaterialPageRoute(builder: (context)=>RegisterScaffold())),
          child: const Icon(Icons.add)),
    );
  }
}

