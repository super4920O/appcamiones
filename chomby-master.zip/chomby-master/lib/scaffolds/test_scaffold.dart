import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:stomp_dart_client/stomp_dart_client.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

class TestScaffold extends StatefulWidget {
  const TestScaffold({super.key});

  @override
  State<TestScaffold> createState() => _TestScaffoldState();
}

class _TestScaffoldState extends State<TestScaffold> {

  late StompClient _stompClient;
  String _message = "Esperando mensajes de websocket";

  @override
  void initState() {
    super.initState();
    _stompClient = StompClient(
      config: StompConfig.sockJS(
        url: 'http://10.0.2.2:8080/gs-guide-websocket',
        onConnect: _onConnect,
        onWebSocketError: (dynamic err)=>log("Error: ${err.toString()}",level:5),
      )
    );

    _stompClient.activate();
  }

  @override
  void dispose() {
    super.dispose();
    _stompClient.deactivate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text(_message),
      ),
    );
  }

  void _onConnect(StompFrame frame){
    _stompClient.subscribe(
        destination: '/topic/app',
        callback: (StompFrame frame){
          setState(() => _message = frame.body!);
        }
    );
  }
}
