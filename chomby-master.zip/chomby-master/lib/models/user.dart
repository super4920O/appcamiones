class User{

  int? id;
  String email;
  String fullName;

  User({this.id,required this.email,required this.fullName});


  factory User.fromJson(Map<String,dynamic> data){
    return User(
      id:data["id"],
      email:data["email"],
      fullName:data["fullName"]
    );
  }

  Map<String,dynamic> toJson(){
    return {
      "id":id,
      "email":email,
      "name":fullName
    };
  }

  @override
  String toString() {
    return "{id:$id, email: $email, name: $fullName}";
  }
}