import 'package:chomby/utils/http_response.dart';

abstract class AuthUseCase {
  void login({required String email,required String password,Function(HttpResponse)? onSuccess,Function? onError});
  void register({required String name, required String email, required String password, required String passwordConfirmation,Function(HttpResponse)? onSuccess,Function onError});
}