
import 'package:chomby/authentication/requests/register_user_request.dart';
import 'package:chomby/authentication/responses/ok_login_response.dart';
import 'package:chomby/authentication/responses/ok_register_response.dart';
import 'package:chomby/authentication/services/auth_service.dart';
import 'package:chomby/authentication/use_cases/auth_use_case.dart';

import 'package:chomby/services/local_storage_service.dart';
import 'package:chomby/utils/http_response.dart';

class DefaultAuthUseCase implements AuthUseCase {

  AuthService authService;
  LocalStorageService localStorageService;

  DefaultAuthUseCase({required this.authService,required this.localStorageService});

  @override
  void login(
      {required String email,
      required String password,
      Function(HttpResponse response)? onSuccess,
      Function? onError})
  {
    authService.login(email: email, password: password)
        .then((response) {

          if(response.statusCode == 200){
            final okLoginResponse = response as OkLoginResponse;

            localStorageService
                .putAsync("token", okLoginResponse.mapJsonBody().token)
                .catchError((err) => onError?.call(err));
          }

          onSuccess?.call(response);


    }).catchError(print);
  }

  @override
  void register({required String name,required String email, required String password, required String passwordConfirmation,Function(HttpResponse)? onSuccess,Function? onError}) {
    authService.register(RegisterUserRequest(
        name: name,
        email: email,
        password:password,
        passwordConfirmation:passwordConfirmation)
    ).then((response){
      if(response.statusCode == 201){
        final okRegisterResponse = response as OkRegisterResponse;
        
        localStorageService
        .putAsync("token", okRegisterResponse.mapJsonBody().token)
        .catchError(print);

        onSuccess?.call(response);
      }
    }).catchError(print);
  }



}