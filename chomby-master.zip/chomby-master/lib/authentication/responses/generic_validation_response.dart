
import 'dart:convert';

import 'package:chomby/utils/http_response.dart';

class GenericValidationResponse extends HttpResponse<GenericValidationResponseBody>{

  GenericValidationResponse({required super.statusCode,required super.headers,required super.body});

  @override
  GenericValidationResponseBody mapJsonBody() {
    return GenericValidationResponseBody.fromJson(jsonDecode(body));
  }

}

class GenericValidationResponseBody{
  String message;
  Map<String,String> errors;

  GenericValidationResponseBody({required this.message,required this.errors});

  factory GenericValidationResponseBody.fromJson(Map<String,dynamic> json){
    return GenericValidationResponseBody(
      message: json["message"],
      errors: json["errors"],
    );
  }
}