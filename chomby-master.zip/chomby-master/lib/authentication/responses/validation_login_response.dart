import 'dart:convert';

import 'package:chomby/utils/http_response.dart';

class ValidationLoginResponse extends HttpResponse<ValidationLoginResponseBody>{

  ValidationLoginResponse({required super.statusCode, required super.headers, required super.body});

  @override
  ValidationLoginResponseBody mapJsonBody() {
    return ValidationLoginResponseBody.fromJson(jsonDecode(body));
  }

}

class ValidationLoginResponseBody {
  String message;
  Map<String,dynamic> errors;

  ValidationLoginResponseBody({required this.errors, required this.message});

  factory ValidationLoginResponseBody.fromJson(Map<String,dynamic> json){
    return ValidationLoginResponseBody(
      message: json["message"],
      errors: json["errors"]
    );
  }
}