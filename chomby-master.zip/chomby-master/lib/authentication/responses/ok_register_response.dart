import 'dart:convert';

import 'package:chomby/models/user.dart';
import 'package:chomby/utils/http_response.dart';

class OkRegisterResponse extends HttpResponse<OkRegisterResponseBody>{
  OkRegisterResponse({required super.statusCode, required super.headers, required super.body});


  @override
  OkRegisterResponseBody mapJsonBody() {
    return OkRegisterResponseBody.fromJson(jsonDecode(body));
  }

}

class OkRegisterResponseBody{
  String token;
  User user;

  OkRegisterResponseBody({required this.token, required this.user});

  factory OkRegisterResponseBody.fromJson(Map<String,dynamic> json){
    return OkRegisterResponseBody(
        token:json["token"],
        user:User.fromJson(json["user"])
    );
  }
}