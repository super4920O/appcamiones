import 'dart:convert';

import 'package:chomby/utils/http_response.dart';

class NotValidCedentialsResponse extends HttpResponse<NotValidCredentialsResponseBody>{

  NotValidCedentialsResponse({required super.statusCode, required super.headers, required super.body});

  @override
  NotValidCredentialsResponseBody mapJsonBody() {

    mapedBody ??= NotValidCredentialsResponseBody.fromJson(jsonDecode(body));

    return mapedBody!;
  }

}

class NotValidCredentialsResponseBody{
  String message;
  NotValidCredentialsResponseBody({required this.message});

  factory NotValidCredentialsResponseBody.fromJson(Map<String,dynamic> json){
    return NotValidCredentialsResponseBody(
      message: json["message"]
    );
  }
}