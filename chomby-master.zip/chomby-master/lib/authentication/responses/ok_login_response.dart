import 'dart:convert';

import 'package:chomby/models/user.dart';
import 'package:chomby/utils/http_response.dart';

class OkLoginResponse extends HttpResponse<OkLoginResponseBody>{

  OkLoginResponse({required super.statusCode, required super.headers, required super.body});

  @override
  OkLoginResponseBody mapJsonBody() {
    return OkLoginResponseBody.fromJson(jsonDecode(body));
  }

}

class OkLoginResponseBody{
  String token;
  User user;

  OkLoginResponseBody({required this.token,required this.user});

  factory OkLoginResponseBody.fromJson(Map<String,dynamic> json){
    return OkLoginResponseBody(
      token: json["token"],
      user: User.fromJson(json["user"])
    );
  }

}