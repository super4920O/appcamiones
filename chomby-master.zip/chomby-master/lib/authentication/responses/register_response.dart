import 'package:chomby/models/user.dart';

class RegisterResponse {
  String token;
  User user;
  
  RegisterResponse({required this.token,required this.user});
  
  factory RegisterResponse.fromJson(Map<String,dynamic> json){
    
    return RegisterResponse(
      token: json["token"],
      user: User.fromJson(json["user"])
    );
  }

  @override
  String toString() {
    return "{user:$user,token:$token}";
  }
}