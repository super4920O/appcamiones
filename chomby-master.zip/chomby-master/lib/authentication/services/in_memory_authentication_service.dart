import 'dart:developer';

import 'package:chomby/authentication/responses/ok_login_response.dart';
import 'package:chomby/authentication/requests/register_user_request.dart';
import 'package:chomby/authentication/responses/register_response.dart';
import 'package:chomby/authentication/services/auth_service.dart';
import 'package:chomby/utils/application/application_container_service.dart';
import 'package:chomby/utils/factories/http_response_factory/login_response_factory.dart';
import 'package:chomby/utils/http_response.dart';

class InMemoryAuthenticationService implements AuthService {

  String email = "daniel@mail.com";
  String password = "123456";

  @override
  Future<HttpResponse> login({required String email, required String password}) async {

/*    return ApplicationContainerService
        .inject<LoginResponseFactory>()
      .createResponse(
        statusCode,
        headers,
        body)
    ;*/

    if(this.email == email && this.password == password){
      return OkLoginResponse(statusCode: 200, headers: {}, body: """{"token":"toekn_de_prueba","user":{"id":1,"email":"daniel@mail.com","fullName":"Daniel Reyes Epitacio"}}""");
    }

    throw Exception("Credenciales inválidas");
  }

  @override
  Future<HttpResponse> register(RegisterUserRequest request) {
    // TODO: implement register
    throw UnimplementedError();
  }

}