import 'package:chomby/authentication/requests/register_user_request.dart';
import 'package:chomby/utils/http_response.dart';


abstract class AuthService {

  Future<HttpResponse> login({required String email,required String password});
  Future<HttpResponse> register(RegisterUserRequest request);

}