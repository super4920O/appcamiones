import 'dart:convert';

import 'package:chomby/authentication/requests/register_user_request.dart';
import 'package:chomby/authentication/services/auth_service.dart';
import 'package:chomby/utils/factories/http_response_factory/login_response_factory.dart';
import 'package:chomby/utils/factories/http_response_factory/register_http_response_factory.dart';
import 'package:chomby/utils/http_response.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;

class DefaultAuthService implements AuthService{

  String BASE_URL = dotenv.env["BASE_URL"] ?? "";

  @override
  Future<HttpResponse> login({required String email, required String password}) async {

    final response = await http.post(
      Uri.parse("$BASE_URL/login"),
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Accept": "application/json"
      },
      body: jsonEncode({
        "username": email,
        "password": password
      }),
    );

    return LoginResponseFactory
          .singleton()
          .createResponse(
            response.statusCode,
            response.headers,
            utf8.decode(response.bodyBytes)
    );
  }

  @override
  Future<HttpResponse> register(RegisterUserRequest request) async {
    final response = await http.post(
      Uri.parse("$BASE_URL/register"),
      headers: {
        "Content-Type":"application/json",
        "Accept":"application/json"
      },
      body: jsonEncode(request.toJson())
    );

    return RegisterHttpResponseFactory
            .singleton()
            .createResponse(
              response.statusCode,
              response.headers,
              utf8.decode(response.bodyBytes)
    );
  }

}