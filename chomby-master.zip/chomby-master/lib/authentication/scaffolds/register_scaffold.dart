import 'package:chomby/authentication/requests/register_user_request.dart';
import 'package:chomby/authentication/use_cases/auth_use_case.dart';
import 'package:chomby/scaffolds/profile/home_profile.dart';
import 'package:chomby/scaffolds/profile/navigation_scaffold.dart';
import 'package:chomby/services/user_service.dart';
import 'package:chomby/authentication/services/auth_service.dart';
import 'package:chomby/utils/validations.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/user.dart';

class RegisterScaffold extends StatefulWidget {
  final User? user;

  const RegisterScaffold({super.key, this.user});

  @override
  State<RegisterScaffold> createState() => _RegisterScaffoldState();
}

class _RegisterScaffoldState extends State<RegisterScaffold> {
  late AuthService _authService;
  late UserService _userService;
  late AuthUseCase _authUseCase;

  final _formKey = GlobalKey<FormState>();
  final _nameEditController = TextEditingController();
  final _emailEditController = TextEditingController();
  final _passwordEditController = TextEditingController();
  final _passwordConfirmationEditController = TextEditingController();

  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    _authService = Provider.of<AuthService>(context, listen: false);
    _userService = Provider.of<UserService>(context, listen: false);
    _authUseCase = Provider.of<AuthUseCase>(context, listen: false);

    if (widget.user != null) {
      _nameEditController.text = widget.user!.fullName;
      _emailEditController.text = widget.user!.email;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
            widget.user == null ? "Registrar usuario" : "Actualizar usuario"),
      ),
      body: SafeArea(
        child: Center(
          child: isLoading
              ? const CircularProgressIndicator()
              : Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          "Bienvenido a Chomby",
                          style: TextStyle(
                            fontSize: 30,
                          ),
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          "Ingresa tus datos",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        TextFormField(
                          controller: _nameEditController,
                          validator: Validations.notEmpty,
                          decoration:
                              const InputDecoration(labelText: "Nombre"),
                        ),
                        TextFormField(
                          controller: _emailEditController,
                          validator: Validations.email,
                          decoration: const InputDecoration(
                              labelText: "Correo electrónico"),
                        ),
                        TextFormField(
                          controller: _passwordEditController,
                          validator: (value) {
                            if (widget.user == null) {
                              // Si es un nuevo registro, la contraseña es obligatoria
                              return Validations.notEmpty(value);
                            }
                            // Si el usuario existe, puedes permitir que el campo esté vacío
                            return null; // No hay validación si el usuario ya existe
                          },
                          obscureText: true,
                          decoration:
                              const InputDecoration(labelText: "Contraseña"),
                        ),
                        TextFormField(
                          controller: _passwordConfirmationEditController,
                          validator: (value) {
                            if (widget.user != null) {
                              return null;
                            }
                            if (value == null || value.isEmpty) {
                              return "Este campo es requerido";
                            }

                            if (value != _passwordEditController.text) {
                              return "Las contraseñas no coinciden";
                            }

                            return null;
                          },
                          obscureText: true,
                          decoration: const InputDecoration(
                              labelText: "Repetir contraseña"),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                              onPressed: () {
                                if (_formKey.currentState!.validate()) {
                                  setState(() {
                                    isLoading = true;
                                  });

                                  _authUseCase.register(
                                      name: _nameEditController.text,
                                      email: _emailEditController.text,
                                      password: _passwordEditController.text,
                                      passwordConfirmation:
                                          _passwordConfirmationEditController
                                              .text,
                                      onSuccess: (response) {
                                        if (response.statusCode == 201) {
                                          Navigator.of(context).pushReplacement(
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      const NavigationScaffold()));
                                        }
                                      },
                                      onError: (err) => showDialog(
                                          context: context,
                                          builder: (context) {
                                            return AlertDialog(
                                              title: const Text("Error"),
                                              content: const Text(
                                                  "No se ha podido realizar la operacion"),
                                              actions: [
                                                TextButton(
                                                    onPressed: () =>
                                                        Navigator.of(context)
                                                            .pop(),
                                                    child: const Text("Ok"))
                                              ],
                                            );
                                          }));
                                }
                              },
                              child: Text(widget.user == null
                                  ? "Registrarse"
                                  : "Actualizar")),
                        ),
                        /*Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text("¿Ya tienes una cuenta?"),
                            TextButton(
                                onPressed: () => Navigator.of(context)
                                    .pushReplacement(MaterialPageRoute(
                                        builder: (context) =>
                                            const LoginScaffold())),
                                child: const Text("Inicia sesión"))
                          ],
                        )*/
                      ],
                    ),
                  ),
                ),
        ),
      ),
    );
  }
}
