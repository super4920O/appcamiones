import 'dart:developer';
import 'package:chomby/authentication/responses/not_valid_credentials_login_response.dart';
import 'package:chomby/authentication/responses/validation_login_response.dart';
import 'package:chomby/components/modals.dart';
import 'package:chomby/authentication/scaffolds/register_scaffold.dart';
import 'package:chomby/scaffolds/profile/navigation_scaffold.dart';
import 'package:chomby/authentication/use_cases/auth_use_case.dart';
import 'package:chomby/utils/http_response.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class LoginScaffold extends StatefulWidget {
  const LoginScaffold({super.key});

  @override
  State<LoginScaffold> createState() => _LoginScaffoldState();
}

class _LoginScaffoldState extends State<LoginScaffold> {

  Map<String, dynamic> _errors = {};
  late AuthUseCase _authUseCase;
  bool isLoading = false;
  final _emailTextFormFieldController = TextEditingController();
  final _passwordTextFormFieldController = TextEditingController();
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    _authUseCase = Provider.of<AuthUseCase>(context, listen: false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: isLoading
              ? const CircularProgressIndicator()
              : _buildLoginForm(),
        ),
      ),
    );
  }

  Widget _buildLoginForm() {
    return Form(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "Chomby",
              style: TextStyle(fontSize: 35),
            ),
            const SizedBox(height: 30),
            const Text(
              "Iniciar sesión",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Text(
              errorMessage ?? "",
              style: const TextStyle(color: Colors.red),
            ),
            TextFormField(
              controller: _emailTextFormFieldController,
              decoration: InputDecoration(
                labelText: "Correo Electrónico",
                errorText: _errors["username"],
              ),
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: _passwordTextFormFieldController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: "Contraseña",
                errorText: _errors["password"],
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              child: ElevatedButton(
                onPressed: _handleLoginButtonPress,
                child: const Text("Iniciar sesión"),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text("¿Aún no tienes una cuenta?"),
                TextButton(
                  onPressed: () => Navigator.of(context).pushReplacement(
                    MaterialPageRoute(
                      builder: (context) => const RegisterScaffold(),
                    ),
                  ),
                  child: const Text("Registrarse"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _handleLoginButtonPress() {
    setState(() => isLoading = true);
    _authUseCase.login(
      email: _emailTextFormFieldController.text,
      password: _passwordTextFormFieldController.text,
      onSuccess: _handleLoginResponse,
      onError: _handleLoginError,
    );
  }

  void _handleLoginError(Exception err) {
    setState(() {
      isLoading = false;
      errorMessage = err.toString();
    });
    showInfoDialog(
      context: context,
      title: "Error",
      content: errorMessage ?? "Error desconocido",
    );
  }

  void _handleLoginResponse(HttpResponse response) {
    setState(() => isLoading = false);

    switch (response.statusCode) {
      case 200:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const NavigationScaffold()),
        );
        break;
      case 400:
        final responseBody = response.mapJsonBody() as ValidationLoginResponseBody;
        setState(() {
          _errors = responseBody.errors;
        });
        break;
      case 401:
        final responseBody = response.mapJsonBody() as NotValidCredentialsResponseBody;
        setState(() {
          errorMessage = responseBody.message;
        });
        break;
      default:
        setState(() {
          errorMessage = "Error desconocido";
        });
    }
  }
}
