class RegisterUserRequest {

  String name;
  String email;
  String password;
  String passwordConfirmation;

  RegisterUserRequest({required this.name, required this.email, required this.password, required this.passwordConfirmation});

  Map<String,dynamic> toJson(){
    return {
      "fullName":name,
      "username":email,
      "password":password,
      "password_confirmation":passwordConfirmation
    };
  }

}