import 'package:chomby/authentication/scaffolds/login_scaffold.dart';
import 'package:chomby/route/services/in_memory_route_service.dart';
import 'package:chomby/route/services/route_service.dart';
import 'package:chomby/scaffolds/profile/home_profile.dart';
import 'package:chomby/scaffolds/profile/navigation_scaffold.dart';
import 'package:chomby/scaffolds/test_scaffold.dart';
import 'package:chomby/services/api_stomp_service.dart';
import 'package:chomby/services/default_location_manager_service.dart';
import 'package:chomby/services/user_service.dart';
import 'package:chomby/authentication/services/auth_service.dart';
import 'package:chomby/authentication/services/default_auth_service.dart';
import 'package:chomby/services/default_local_storage_service.dart';
import 'package:chomby/authentication/services/in_memory_authentication_service.dart';
import 'package:chomby/services/in_memory_stomp_service.dart';
import 'package:chomby/services/local_storage_service.dart';
import 'package:chomby/services/location_manager_service.dart';
import 'package:chomby/services/static_location_manager_service.dart';
import 'package:chomby/services/stomp_service.dart';
import 'package:chomby/authentication/use_cases/auth_use_case.dart';
import 'package:chomby/authentication/use_cases/default_auth_use_case.dart';
import 'package:chomby/utils/application/application_container_service.dart';
import 'package:chomby/utils/factories/http_response_factory/login_response_factory.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';

void main() async{

  var ma = const MaterialApp();


  await dotenv.load(fileName: ".env");

  //Services
  //Servicios estrucutrados
  const flutterSecureStorage = FlutterSecureStorage();
  final defaultAuthService = InMemoryAuthenticationService();
  final defaultUseService = UserService();
  final defaultLocalStorageService = DefaultLocalStorageService(fss: flutterSecureStorage);
  final defaultLocationManagerService = StaticLocationManagerService();
  final defaultStompService = InMemoryStompService();
  final defaultRouteService = InMemoryRouteService();

  //UseCases
  final defaultAuthUseCase = DefaultAuthUseCase(authService: defaultAuthService,localStorageService: defaultLocalStorageService);

  runApp(
      MultiProvider(
          providers: [
            Provider<AuthService>(create: (_) => defaultAuthService),
            Provider<UserService>(create: (_) => defaultUseService),
            Provider<LocalStorageService>(create: (_) => defaultLocalStorageService),
            Provider<AuthUseCase>(create: (_) => defaultAuthUseCase),
            Provider<LocationManagerService>(create: (_) => defaultLocationManagerService),
            Provider<StompService>(create:(_) => defaultStompService),
            Provider<RouteService>(create: (_)=>defaultRouteService),
          ],
          child:const MyApp()
      ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.purple),
        useMaterial3: true,
      ),
      home: const LoginScaffold(),
    );
  }
}


