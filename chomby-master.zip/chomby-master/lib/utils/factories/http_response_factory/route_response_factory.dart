import 'package:chomby/route/responses/ok_route_info_response.dart';
import 'package:chomby/utils/factories/http_response_factory/http_response_factory.dart';
import 'package:chomby/utils/http_response.dart';

class RouteResponseFactory implements HttpResponseFactory{

  static final RouteResponseFactory _instance = RouteResponseFactory._internal();

  RouteResponseFactory._internal();

  factory RouteResponseFactory.singleton(){
    return _instance;
  }

  @override
  HttpResponse createResponse(int statusCode, Map<String, String> headers, String body) {
    switch(statusCode){
      case 200:
        return OkRouteInfoResponse(statusCode: statusCode, headers: headers, body: body);
      default:
        throw Exception("Exception[RouteResponseFactory]. Not HttpResponse implemeted for STATUS CODE $statusCode");
    }
  }

}