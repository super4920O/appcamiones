import 'package:chomby/utils/http_response.dart';

abstract class HttpResponseFactory {
  HttpResponse createResponse(int statusCode, Map<String,String> headers,String body);
}