import 'package:chomby/authentication/responses/not_valid_credentials_login_response.dart';
import 'package:chomby/authentication/responses/ok_login_response.dart';
import 'package:chomby/authentication/responses/validation_login_response.dart';
import 'package:chomby/utils/factories/http_response_factory/http_response_factory.dart';
import 'package:chomby/utils/http_response.dart';

class LoginResponseFactory implements HttpResponseFactory{

  static final LoginResponseFactory _instance = LoginResponseFactory._internal();

  LoginResponseFactory._internal();

  factory LoginResponseFactory.singleton(){
    return _instance;
  }


  @override
  HttpResponse createResponse(int statusCode, Map<String, String> headers, String body) {
    switch(statusCode){
      case 200:
        return OkLoginResponse(statusCode: statusCode, headers: headers, body: body);
      case 400:
        return ValidationLoginResponse(statusCode: statusCode, headers: headers, body: body);
      case 401:
        return NotValidCedentialsResponse(statusCode: statusCode, headers: headers, body: body);
        default:
          throw Exception("Class [LoginResponseFactory]. Not available HttpResponse implementation for status code $statusCode");
    }
  }
  
}