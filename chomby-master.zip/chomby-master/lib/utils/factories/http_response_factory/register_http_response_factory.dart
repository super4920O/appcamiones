import 'package:chomby/authentication/responses/generic_validation_response.dart';
import 'package:chomby/authentication/responses/ok_register_response.dart';
import 'package:chomby/utils/factories/http_response_factory/http_response_factory.dart';
import 'package:chomby/utils/http_response.dart';

class RegisterHttpResponseFactory implements HttpResponseFactory{

  static final RegisterHttpResponseFactory _instance = RegisterHttpResponseFactory._internal();

  RegisterHttpResponseFactory._internal();

  factory RegisterHttpResponseFactory.singleton(){
    return _instance;
  }

  @override
  HttpResponse createResponse(int statusCode, Map<String, String> headers, String body) {
    switch(statusCode){
      case 201:
        return OkRegisterResponse(statusCode: statusCode, headers: headers, body: body);
      case 400:
        return GenericValidationResponse(statusCode: statusCode, headers: headers, body: body);
      default:
        throw Exception("Not HttpResponse implementation provided for status code $statusCode");
    }
  }

}