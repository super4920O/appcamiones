class ApplicationContainerService {
  static final Map<Type,dynamic> _dependencies = {};

  static void register<T>(Map<Type,dynamic> Function() factories){
    final dependencies = factories.call();
    dependencies.forEach((key,value){
      _dependencies[key] = value;
    });
  }

  static T inject<T>(){
    var dependency =_dependencies[T];
    if(dependency == null){
      throw Exception("Not dependency provided for ${T.toString()}");
    }
    return dependency as T;
  }
}