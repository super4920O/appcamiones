abstract class JsonSerializable<T> {

  T fromJson(Map<String,dynamic> json);
}