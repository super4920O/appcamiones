import 'package:chomby/utils/json_serializable.dart';

abstract class HttpResponse<T> {
  int statusCode;
  Map<String,String> headers;
  String body;
  T? mapedBody;

  HttpResponse({required this.statusCode, required this.headers, required this.body});

  T mapJsonBody();

}