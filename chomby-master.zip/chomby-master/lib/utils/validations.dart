class Validations {
  
  static String? notEmpty(String? value){
    if(value == null || value.isEmpty){
      return "Este campo es requerido";
    }
    return null;
  }
  
  static String? email(String? value){
    if(value == null || value.isEmpty){
      return "Email no válido";
    }
    
    final regex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
    if(!regex.hasMatch(value)){
      return "Email no válido";
    }

    return null;
  }

  static String? validate(List<String? Function(String?)> validators,String? value){
    for(var validator in validators){
      final result = validator(value);
      if(result != null){
        return result;
      }
    }
    return null;
  }
}