import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;

import 'package:chomby/models/user.dart';

class UserService{

  String baseUrl = "${dotenv.env["API_URL"]}/users";

  HttpClient httpClient= HttpClient();

  Future<List<User>> index() async {
    var response = await http.get(Uri.parse(baseUrl));

    if(response.statusCode != 200){
      throw Exception("Error al cargar los usuarios");
    }

    List<dynamic> body = jsonDecode(response.body);
    List<User> users = body.map((item)=>User.fromJson(item)).toList();
    return users;


  }

  Future<User> show(int id) async{

    final response = await http.get(Uri.parse("${baseUrl}/$id"));
    if(response.statusCode == 200){

      return User.fromJson(jsonDecode(response.body));
    }

    throw Exception("No se ha podido cargar el usuario");
  }
  
  Future<User> update(User user) async{
    final response = await http.put(Uri.parse("${baseUrl}/${user.id}"),
      headers: {
        "Content-Type":"application/json",
        "Accept":"application/json"
      },
      body: jsonEncode(user.toJson())
    );
    print(response.body);
    if(response.statusCode == 200){

      return User.fromJson(jsonDecode(response.body));
    }

    throw Exception("No se ha podido actualizar el estado");
  }
  
  Future<User> store(User user)async {
    final response = await http.post(
        Uri.parse(baseUrl),
      headers: {
          "Content-Type":"application/json"
      },
      body: jsonEncode(user.toJson())
    );

    log(response.body);

    if(response.statusCode == 201){
      return  User.fromJson(jsonDecode(response.body));
    }

    throw Exception("No se ha podido crear el usuario");
    
  }

  void delete(int id) async {
    final response = await http.delete(
        Uri.parse("${baseUrl}/${id}"),
      headers: {
          "Content-Type":"application/json",
        "Accept":"application/json"
      }
    );

    print(response.body);

  }
}