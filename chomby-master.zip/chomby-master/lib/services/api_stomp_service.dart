import 'dart:developer';

import 'package:chomby/services/stomp_service.dart';
import 'package:stomp_dart_client/stomp_dart_client.dart';

class ApiStompService implements StompService{

  late StompClient _stompClient;
  Map<String, Function(String message)> _subscriptions = {};

  @override
  void connect() {
    _stompClient = StompClient(
      config: StompConfig(
        url: "ws://10.0.2.2/gs-guide-websocket",
        onConnect: _onConnect,
        onWebSocketError: (dynamic err)=>log(err.toString(),level: 5)
      )
    );

    _stompClient.activate();
  }

  @override
  void disconect() {
    _stompClient.deactivate();
  }

  @override
  void sendMessage(String destination, String message) {
    // TODO: implement sendMessage
  }

  @override
  void subscribe(String destination, Function(String message) callback) {
    _subscriptions[destination] = callback;
  }

  void _onConnect(StompFrame frame){
    _stompClient.subscribe(
        destination: "/topic/position",
        callback: (StompFrame frame){
          _subscriptions["/topic/position"]?.call(frame.body!);
        }
    );
  }

}