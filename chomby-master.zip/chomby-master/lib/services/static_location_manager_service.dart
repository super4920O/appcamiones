import 'package:chomby/services/location_manager_service.dart';
import 'package:geolocator/geolocator.dart';

class StaticLocationManagerService implements LocationManagerService{

  @override
  Future<Position> getCurrentPosition() {
    return Future.value(Position(
      latitude: 19.057428,
      longitude: -98.152918,
      timestamp: DateTime.now(),
      altitude: 0.0,
      altitudeAccuracy: 0.0,
      accuracy: 0.0,
      heading: 0.0,
      headingAccuracy: 0.0,
      speed: 0.0,
      speedAccuracy: 0.0,
    ));
  }


}