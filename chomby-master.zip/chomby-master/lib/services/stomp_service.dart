import 'package:stomp_dart_client/stomp_dart_client.dart';

abstract class StompService {
  void connect();
  void disconect();
  void subscribe(String destination,Function(String message) callback);
  void sendMessage(String destination, String message);
}