import 'package:chomby/services/location_manager_service.dart';
import 'package:geolocator/geolocator.dart';

class DefaultLocationManagerService implements LocationManagerService{

  @override
  Future<Position> getCurrentPosition() async {
    Position position = await Geolocator.getCurrentPosition();
    return position;
  }

}