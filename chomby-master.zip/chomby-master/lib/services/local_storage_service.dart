abstract class LocalStorageService {

  bool put(String key,Object value);

  Future<dynamic> putAsync(String key,Object value,{Function? onSuccess,Function onError});
}