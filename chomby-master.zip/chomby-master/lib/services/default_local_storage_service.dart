import 'package:chomby/services/local_storage_service.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class DefaultLocalStorageService implements LocalStorageService {
  FlutterSecureStorage fss;

  DefaultLocalStorageService({required this.fss});

  @override
  bool put(String key, Object value) {
    // TODO: implement putAsync
    throw UnimplementedError();
  }

  @override
  Future putAsync(String key, Object value,
      {Function? onSuccess, Function? onError}) async {
    if (value is String) {}

    try {
      await fss.write(key: key, value: value.toString());
      onSuccess?.call();
    } catch (err) {
      onError?.call(err);
    }
  }

}
