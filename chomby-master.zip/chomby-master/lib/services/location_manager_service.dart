import 'package:geolocator/geolocator.dart';

abstract class LocationManagerService {

  Future<Position> getCurrentPosition();
}